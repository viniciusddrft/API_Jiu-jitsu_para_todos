from flask import Flask,jsonify
import os





app = Flask(__name__)

data = {
    "title" : "Homem Aranha",
    "url" : "https://homemaranha.com.br"
}

@app.route("/",methods =["GET"])
def api():



    return jsonify(data)







if(__name__ == '__main__'):
    port = int(os.environ.get("PORT",5000))
    app.run(debug=True,port=port)
    #host="0.0.0.0"